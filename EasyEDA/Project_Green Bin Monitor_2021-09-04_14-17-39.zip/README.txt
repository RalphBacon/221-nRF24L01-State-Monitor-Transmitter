Monitors the state of the lids over the green storage bins and transmits the state via an nRF24L01+ (and UNO-type microcontroller) to a receiver in the workshop.            
How to use：

At editor, Click the document icon on the topbar, via "Document" > "Open" > "EasyEDA Source", and select json file, then open it at the editor.



如何使用：

在编辑器顶部工具栏，点击“文档”图标，选择 “文档” > “打开” > “EasyEDA源码”，选择json文件打开即可。